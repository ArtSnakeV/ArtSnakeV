﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomainClassLibrary
{
    public class Book
    {
        public int Id { get; set; }
        //[Column("title")]
        public string Title { get; set; } = default!;

        public decimal Price { get; set; }

        public int AuthorId { get; set; }

        public virtual Author Author { get; set; } = default!;

        public bool IsDeleted { get; set; }
        
        public int Edition { get; set; }

        public int PublishingId { get; set; }

        public virtual Publishing Publishing { get; set; } = default!;
    }
}
