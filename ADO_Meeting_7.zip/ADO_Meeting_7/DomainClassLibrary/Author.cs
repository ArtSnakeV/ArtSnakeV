﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomainClassLibrary
{
    public class Author
    {
        public int Id { get; set; }

        public string Firstname { get; set; } = default!;

        public string Surname { get; set; } = default!;

        public int YearOfBirth { get; set; }

        public int CountryId { get; set; }
        //Navigation property - навігаційна властивість
        public virtual Country Country { get; set; } = default!;

        public virtual ICollection<Book> Books { get; set; } = default!;
    }
}
