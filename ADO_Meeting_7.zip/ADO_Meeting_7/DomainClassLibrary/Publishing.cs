﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomainClassLibrary
{
    public class Publishing
    {
        public int Id { get; set; }

        public string Name { get; set; } = default!;

        public string? City { get; set; }

        public virtual ICollection<Book> Books { get; set; } = default!;
    }
}
