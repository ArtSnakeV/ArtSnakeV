﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomainClassLibrary
{
    public class Country
    {
        public int Id { get; set; }
        public string Name { get; set; } = default!;

        public virtual ICollection<Author> Authors { get; set; } = default!;
    }
}
