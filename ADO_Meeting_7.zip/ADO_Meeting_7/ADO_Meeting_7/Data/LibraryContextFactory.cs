﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADO_Meeting_7.Data
{
    public class LibraryContextFactory : IDbContextFactory<LibraryContext>
    {
        public LibraryContext CreateDbContext()
        {
            ConfigurationBuilder configurationBuilder = new ConfigurationBuilder();
            configurationBuilder.AddJsonFile("appSettings.json");
            var configuration = configurationBuilder.Build();
            string? connStr = configuration.GetConnectionString("MSSQLLibrary") ??
                throw new InvalidOperationException("You should provide MSSQLLibrary connection string!");
            DbContextOptionsBuilder<LibraryContext> optionsBuilder = new DbContextOptionsBuilder<LibraryContext>();
            optionsBuilder.UseSqlServer(connStr);
            DbContextOptions<LibraryContext> options = optionsBuilder.Options;
            LibraryContext context = new LibraryContext(options);
            return context;
        }
    }
}
