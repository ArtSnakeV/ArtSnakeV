﻿// See https://aka.ms/new-console-template for more information
using ADO_Meeting_7.Data;
using DomainClassLibrary;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System.Text;

Console.OutputEncoding = Encoding.UTF8;
ConfigurationBuilder configurationBuilder = new ConfigurationBuilder();
configurationBuilder.AddJsonFile("appSettings.json");
var configuration = configurationBuilder.Build();
string? connStr = configuration.GetConnectionString("MSSQLLibrary") ??
    throw new InvalidOperationException("You should provide MSSQLLibrary connection string!");
DbContextOptionsBuilder<LibraryContext> optionsBuilder = new DbContextOptionsBuilder<LibraryContext>();
optionsBuilder.UseSqlServer(connStr);
DbContextOptions<LibraryContext> options = optionsBuilder.Options;
using(LibraryContext context = new LibraryContext(options))
{
    //EagerLoadingExample1(context);
    //EagerLoadingExample2(context);
    ////Lazy Loading - ліниве завантаження
    Author? author2 = context.Authors.Include(t => t.Country).FirstOrDefault(t => t.Id == 2);
    foreach (Author author in context.Authors.ToList())
    {
        Console.WriteLine($"{author.Id}. {author.Firstname} {author.Surname} ");
        if (author.Country != null)
            Console.WriteLine($"З країни: {author.Country.Name}");
        if(author.Books!= null)
        {
            Console.WriteLine("Всі книги автора:");
            foreach(Book book in author.Books.ToList())
            {
                Console.WriteLine($"{book.Id}. {book.Title}");
            }
        }
        Console.WriteLine("-------------");
    }
}


void EagerLoadingExample1(LibraryContext context)
{
    //Eader loading - Жадібне завантаження
    var authors = context.Authors.Include(t => t.Country);
    foreach (var author in authors)
        Console.WriteLine($"{author.Id}. {author.Firstname} {author.Surname} " +
            $"from {author.Country.Name}");
}

void EagerLoadingExample2(LibraryContext context)
{
    var books = context.Books.Include(t => t.Author).ThenInclude(a => a.Country);
    foreach (var book in books)
    {
        Console.WriteLine($"{book.Id}. {book.Title}.");
        if (book.Author != null)
            Console.WriteLine($"Author: {book.Author.Firstname} {book.Author.Surname}");
        if (book.Author != null && book.Author.Country != null)
            Console.WriteLine($"From country: {book.Author.Country.Name}");
        Console.WriteLine("-----------");
    }
}

void ImplicitLoadingExample1(LibraryContext context)
{
    //1. Implicit Loading - Явне завантаження
    var authors = context.Authors;
    //context.Countries.Load();
    foreach (var author in authors)
        Console.WriteLine($"{author.Id}. {author.Firstname} {author.Surname} " +
            $"from {author.Country.Name}");
}

//2. Implicit Loading - Явне завантаження 2
void ImplicitLoadingExample2(LibraryContext context)
{
    
    Author? author = context.Authors.FirstOrDefault();
    if (author != null)
    {
        context.Entry(author).Reference(t => t.Country).Load();
        context.Entry(author).Collection(t => t.Books).Load();
        Console.WriteLine($"{author.Id}. {author.Firstname} {author.Surname}");
        if (author.Country != null)
            Console.WriteLine($"From country: {author.Country.Name}");
        else
            Console.WriteLine("Information about country is not loaded");
        if (author.Books != null)
        {
            Console.WriteLine("Всі книги автора");
            foreach (var book in author.Books)
            {
                Console.WriteLine($"{book.Id}. {book.Title}, {book.Price} грн.");
            }
        }
        else
            Console.WriteLine("Книги відсутні або не завантажені");
    }
}