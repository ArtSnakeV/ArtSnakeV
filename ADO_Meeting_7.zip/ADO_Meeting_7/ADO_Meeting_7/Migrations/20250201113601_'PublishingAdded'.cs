﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ADO_Meeting_7.Migrations
{
    /// <inheritdoc />
    public partial class PublishingAdded : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "PublishingId",
                table: "Books",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateTable(
                name: "Publishings",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    City = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Publishings", x => x.Id);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Books_PublishingId",
                table: "Books",
                column: "PublishingId");

            migrationBuilder.AddForeignKey(
                name: "FK_Books_Publishings_PublishingId",
                table: "Books",
                column: "PublishingId",
                principalTable: "Publishings",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Books_Publishings_PublishingId",
                table: "Books");

            migrationBuilder.DropTable(
                name: "Publishings");

            migrationBuilder.DropIndex(
                name: "IX_Books_PublishingId",
                table: "Books");

            migrationBuilder.DropColumn(
                name: "PublishingId",
                table: "Books");
        }
    }
}
